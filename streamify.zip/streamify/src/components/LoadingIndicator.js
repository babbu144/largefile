// src/components/LoadingIndicator.js
import React from 'react';

const LoadingIndicator = () => {
  return <div>Loading...</div>;
};

export default LoadingIndicator;
